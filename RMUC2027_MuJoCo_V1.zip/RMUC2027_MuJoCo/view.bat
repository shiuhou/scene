@echo off
setlocal
pushd "%~dp0"
if errorlevel 1 exit /b 1
if not exist ".venv\Scripts\python.exe" goto need_setup
".venv\Scripts\python.exe" "view_field.py" %*
if errorlevel 1 goto failed
popd
exit /b 0
:need_setup
echo Please run setup.bat first.
:failed
echo Viewer did not start or exited with an error. See the message above.
popd
pause
exit /b 1
