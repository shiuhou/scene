# 来源与权利说明

场地源仓库：https://github.com/CosmosMount/rm_mjcf

基线提交：6314b1ad629bb203dc12c62666e4823159eb37b4

源文件身份、建模修改和校验值见 `rm_mjcf/rmuc2027_battlefield_mjcf/provenance.json`。

## 上游权利说明（原文）


各模型和资产的权利归其原作者所有。上游未附带许可证的模型不因此获得新的
许可；使用或再分发前请自行确认授权。WBR 的详细来源和校验值见
`rm26_pnx_wbr_mjcf/README.md` 与 `UPSTREAM.json`。
