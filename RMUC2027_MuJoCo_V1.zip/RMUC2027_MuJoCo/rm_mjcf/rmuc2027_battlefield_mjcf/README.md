# RMUC2027 V1 静态赛场

基于用户提供的 2027 规则与 CAD 补全的 MuJoCo 场地。包含彩色 CAD 外观、分离的凸碰撞面、实际 1.5° 地面倾斜、6 个隧道、起伏公路，以及补充的围栏和雷达平台。运行资产全部使用相对路径，不依赖 SolidWorks 或转换工具。

推荐并验证的运行版本为 **MuJoCo 3.16.0**。旧版 3.3.7 对大量命名网格的解析很慢。

## 本地工作目录快速启动

在本次交付的 `场地mujoco\rm_mjcf\rmuc2027_battlefield_mjcf` 目录中打开 PowerShell，运行：

```powershell
& "..\..\.venv\Scripts\python.exe" "..\..\view_field.py"
```

虚拟环境和缓存启动器位于上两级的 `场地mujoco` 工作目录；本模型目录只包含运行资产。单独复制模型目录时，请在自己的 Python 环境中安装 MuJoCo，再使用下方的 Python 加载示例。

## 入口与坐标

| 文件 | 用途 |
|---|---|
| `model.xml` | 中心坐标入口，推荐；米、弧度、Z 向上，-X 红方、+X 蓝方 |
| `model_cad.xml` | 与源 CAD 换算成米后的坐标一致 |
| `assets.xml` | 彩色视觉网格及局部凸碰撞网格定义 |
| `field.xml` | 场地 body，供自定义场景包含 |
| `provenance.json` | 源文件及输出哈希、建模近似、实际验证结果 |

`p_field = p_cad + [-0.000007206605, -1.6243436765, 1.6403436765]`。

中心原点是场地中轴线地面。地面向两条长边倾斜 1.5°；全场并非 Z=0。CAD 地板还包含场边延伸，规则核心区为 28 m × 15 m。

在本目录运行：

```python
import mujoco
import mujoco.viewer
m = mujoco.MjModel.from_xml_path("model.xml")
d = mujoco.MjData(m)
mujoco.viewer.launch(m, d)
```

Windows 下请先进入本目录再加载文件名，以避开部分版本的中文绝对路径问题。整场细节较多，首次 XML 加载耗时与内存占用高于简化地形模型；父工作目录提供有内容哈希校验的 MJB 缓存启动器。

## 视觉、碰撞与集成

视觉在 group 2，`contype=conaffinity=0`；碰撞在 group 3，默认透明，`contype=conaffinity=1`。显示 group 3 前需将碰撞几何 alpha 调为 1。不要直接让整块视觉网格参与碰撞，否则凸包会封住凹形地形和通道。

自定义机器人 XML 可以放在本目录，与 `model.xml` 同级：保留其 `visual` / `collision` 默认类，根级包含 `assets.xml`，在 `worldbody` 中包含 `field.xml`。入口放在其他目录时还需对应调整包含路径和 `compiler.meshdir`。

地形采用 CAD 曲面分片凸化；矩形面使用倾斜盒，梯形及其它凸多边形保留真实轮廓。起伏路段按 CAD 边界横截面沿原挤出方向展开，提取时检查原始顶点偏差不超过 1 mm。碰撞壳通常厚 2 mm，表面两侧各约 1 mm。

## 来源与近似

原仓库基线为 [CosmosMount/rm_mjcf](https://github.com/CosmosMount/rm_mjcf/tree/main/rmuc2027_battlefield_mjcf) 的 `6314b1ad629bb203dc12c62666e4823159eb37b4`。源 CAD 发布仓库为 [shiuhou/scene](https://github.com/shiuhou/scene/tree/a4f31da5e724a0dc7bd6ecef59221c838833975c)。用户 STEP 与上游哈希一致，用户 SLDASM 哈希不同；对原生装配做了只读解析和 81 个零件实例的放置/包围盒对应核查，不声称逐面 BRep 等价。

颜色保留 CAD 信息并统一红蓝方向，未指定材质采用近似外观。围栏高度 2.4 m；雷达平台 3.4 m × 1.16 m、平台高度约 2.4 m、护栏高 1.1 m 来自规则。钢材截面、网格、楼梯和部分安装间隙为示意。

小于 10 mm 的孔洞、小于 25 mm 的连接硬件及较小的独立面经过简化。地形独立面面积阈值为 1 cm²，道具为 10 cm²。摩擦与接触软硬度未实测标定。曲面离散、减面和碰撞壳都有误差；抽样通过不意味着全部接触已认证。

本模型是 CAD 发布姿态下的**静态场地**。没有能量机关/前哨站转动、基地护甲与闸门控制、能量单元拾取和磁吸、风机气流、命中计分或裁判状态机；这些需要在具体机器人任务中另行接入。

## 验证

完整机器可读结果保存在 `provenance.json`：两个入口加载与坐标变换、2,553 个表面采样、与原始 629 个 AABB 基线比较、5 个动态落体探针、6 个隧道测试箱扫掠及顶板接触、从独立复制目录加载两个入口。场地本身无自由度，动态验证是在额外加入探针的独立场景中进行。

垂直射线误差不是表面法向距离：接近竖直的薄板会放大 1 mm 壳厚，省略的小零件也可能使射线落到下方结构。实际最大差异和超差数量均保留在报告中，不只报告平均值。

源 CAD 和规则文档的权利归原作者所有。保留上游来源；源 CAD 仓库未附许可文件。
