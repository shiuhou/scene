"""Portable XML loading and content-addressed, version-specific MJB cache."""
from pathlib import Path
import hashlib
import os
import time
import mujoco

ROOT=Path(__file__).resolve().parent
MODEL=ROOT/'rm_mjcf/rmuc2027_battlefield_mjcf'

def cache_path(cad_frame=False):
    entry='model_cad.xml' if cad_frame else 'model.xml'
    digest=hashlib.sha256(mujoco.__version__.encode())
    for path in [MODEL/entry,MODEL/'assets.xml',MODEL/'field.xml',*sorted((MODEL/'assets').glob('visual_*.msh'))]:
        digest.update(path.name.encode());digest.update(path.read_bytes())
    return ROOT/'cache/runtime'/f'{Path(entry).stem}-{digest.hexdigest()[:16]}.mjb'

def save_cached_model(model,cad_frame=False):
    cached=cache_path(cad_frame);cached.parent.mkdir(parents=True,exist_ok=True)
    previous=Path.cwd()
    try:
        os.chdir(MODEL)
        mujoco.mj_saveModel(model,os.path.relpath(cached,MODEL),None)
    finally:
        os.chdir(previous)

def load_field(cad_frame=False, cache=True):
    entry='model_cad.xml' if cad_frame else 'model.xml'
    cached=cache_path(cad_frame)
    previous=Path.cwd()
    try:
        os.chdir(MODEL)
        relative=os.path.relpath(cached,MODEL)
        if cache and cached.exists():
            return mujoco.MjModel.from_binary_path(relative)
        started=time.perf_counter()
        print(f'Loading {entry} with MuJoCo {mujoco.__version__}...',flush=True)
        model=mujoco.MjModel.from_xml_path(entry)
        if cache:
            cached.parent.mkdir(parents=True,exist_ok=True)
            mujoco.mj_saveModel(model,relative,None)
        print(f'Field ready in {time.perf_counter()-started:.1f} s ({model.ngeom} geoms).',flush=True)
        return model
    finally:
        os.chdir(previous)
