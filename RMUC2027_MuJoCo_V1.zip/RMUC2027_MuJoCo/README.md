# RoboMaster 2027 场地 MuJoCo 分享包

完整静态场地、彩色外观和碰撞模型。无需安装 SolidWorks；保持本包目录结构即可移动到其他电脑。

## Windows 快速开始

1. 将 ZIP **全部解压**，进入 `RMUC2027_MuJoCo` 文件夹，不要直接在压缩包中运行。
2. 安装 **Python 3.12（64 位）**，安装时启用 Python Launcher 或勾选加入 PATH。
3. 双击 `setup.bat`，等待依赖安装完成。此步骤需要联网，只需执行一次。
4. 双击 `view.bat` 打开场地。日后直接运行此文件即可。

安装脚本仅在解压目录内创建 `.venv` 并安装 `requirements.txt`，不需要管理员权限。包内未附带 Python 解释器或离线安装包。

如果使用 PowerShell，请先进入**包含本 README 的目录**，运行：

```powershell
.\setup.bat
.\view.bat
```

若已有配置好的 Python 环境，可运行 `python -m pip install -r requirements.txt`，然后运行 `python view_field.py`。

首次打开需从 XML 编译场地，在原测试电脑上约 40 秒；其他电脑用时会不同。随后自动生成约 1.2 GB 的 `cache/runtime/` 缓存，请预留磁盘空间。模型细节较多，首次编译时请等待控制台显示 `Field ready`。缓存由当前 MuJoCo 版本和模型内容决定，无需从发送者电脑复制。

## 查看操作

- 鼠标旋转、平移和缩放沿用 MuJoCo viewer 的操作。
- `C`：切换碰撞显示。最多绘制相机关注点附近 8,000 个碰撞体，全部碰撞体仍参与物理计算。
- `P`：显示或隐藏外围围栏。
- `view.bat --collision`：以碰撞视图打开。
- `view.bat --cad-frame`：使用原 CAD 坐标入口。

## 文件说明

| 文件 | 用途 |
|---|---|
| `rm_mjcf/rmuc2027_battlefield_mjcf/model.xml` | 推荐模型入口，场地中心坐标，米、弧度、Z 向上 |
| 同目录 `model_cad.xml` | CAD 原点坐标入口 |
| 同目录 `assets.xml`、`field.xml`、`assets/` | 完整视觉和碰撞资产，必须一起保留 |
| 同目录 `provenance.json` | 源文件身份、输出哈希和建模近似 |
| `view_field.py`、`field_runtime.py` | 查看器及本地编译缓存加载器 |
| `requirements.txt` | Python 运行依赖，MuJoCo 固定为 3.16.0 |
| `MODEL_NOTES.md` | 集成机器人、坐标关系和建模近似的详细说明 |
| `validation/` | 原建模工作区的接触、隧道及几何验证记录 |
| `previews/` | 场地总览和俯视图 |
| `SOURCE_NOTICE.md` | 来源和保留的上游权利说明 |
| `SHA256SUMS.txt` | 包内文件 SHA256 校验清单（不包含清单自身） |

本包用于查看、机器人场景集成和仿真，不包含原始 PDF、SLDASM、STEP、CAD 转换工具、Git 历史、本机虚拟环境或编译缓存。

## 模型范围与已知近似

这是 CAD 发布姿态下的**静态场地**。能量机关、前哨站、基地护甲和飞镖闸门未加入运动控制，也未加入道具拾取、裁判、血量或得分逻辑。

碰撞采用局部凸体与约 2 mm 厚的曲面壳；细小孔洞和硬件有简化。围栏和雷达平台的部分结构为示意，摩擦与接触参数未实测标定。完整说明见 `MODEL_NOTES.md`。

原工作区在 MuJoCo 3.16.0 上通过两个入口加载、5 个动态落体探针和 6 个隧道测试。2,553 个表面采样的垂直差异中位数约 1.00 mm、95% 分位约 1.07 mm；最大约 293 mm，发生于省略的小硬件处。抽样结果不是全表面误差保证，也不代表接收者硬件已测试。
