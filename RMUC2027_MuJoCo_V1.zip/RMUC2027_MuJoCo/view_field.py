"""Interactive field viewer. C: collision layer; P: perimeter visibility."""
import argparse
import os
from pathlib import Path
import time
import mujoco
import mujoco.viewer
import numpy as np
from field_runtime import load_field

ROOT=Path(__file__).resolve().parent

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--cad-frame',action='store_true')
    p.add_argument('--collision',action='store_true')
    args=p.parse_args()
    m=load_field(args.cad_frame)
    d=mujoco.MjData(m)
    original=m.geom_rgba.copy()
    original_groups=m.geom_group.copy()
    collider_ids=np.flatnonzero(original_groups==3)
    mujoco.mj_forward(m,d)
    state={'collision':args.collision,'perimeter':True,'dirty':True}
    perimeter=np.array([m.body(int(b)).name=='perimeter' for b in m.geom_bodyid])
    def key(code):
        if code==67:
            state['collision']=not state['collision']
            state['dirty']=True
        if code==80:
            state['perimeter']=not state['perimeter']
            state['dirty']=True
    with mujoco.viewer.launch_passive(m,d,key_callback=key) as viewer:
        budget=min(8000,max(100,viewer.user_scn.maxgeom-1000))
        next_selection=0.
        print(f'C: show up to {budget} collision pieces nearest the camera focus. All {len(collider_ids)} colliders remain active in physics. P: fence visibility.',flush=True)
        with viewer.lock():
            viewer.cam.lookat[:]=[0,1.6243436765,-1.1403436765] if args.cad_frame else [0,0,.5]
            viewer.cam.distance=33
            viewer.cam.azimuth=125
            viewer.cam.elevation=-55
        while viewer.is_running():
            start=time.perf_counter()
            with viewer.lock():
                if state['dirty']:
                    m.geom_rgba[:]=original
                    m.geom_group[:]=original_groups
                    if state['collision']:
                        m.geom_rgba[collider_ids]=[.2,.7,.3,1]
                    viewer.opt.geomgroup[2]=not state['collision']
                    viewer.opt.geomgroup[3]=state['collision']
                    viewer.opt.geomgroup[4]=0
                    if not state['perimeter']:
                        m.geom_rgba[perimeter,3]=0
                    state['dirty']=False
                    next_selection=0.
                if state['collision'] and start>=next_selection:
                    distance=np.maximum(0,np.linalg.norm(d.geom_xpos[collider_ids]-viewer.cam.lookat,axis=1)-m.geom_rbound[collider_ids])
                    chosen=collider_ids[np.argsort(distance)[:budget]]
                    m.geom_group[collider_ids]=4
                    m.geom_group[chosen]=3
                    next_selection=start+.25
                mujoco.mj_step(m,d)
            viewer.sync()
            time.sleep(max(0,1/60-(time.perf_counter()-start)))

if __name__=='__main__':
    main()
