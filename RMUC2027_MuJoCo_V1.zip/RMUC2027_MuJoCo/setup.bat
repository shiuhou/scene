@echo off
setlocal
pushd "%~dp0"
if errorlevel 1 exit /b 1
if exist ".venv\Scripts\python.exe" goto install
py -3.12 -c "import struct,sys; sys.exit(struct.calcsize('P') != 8)" >nul 2>nul
if errorlevel 1 goto try_python
py -3.12 -m venv .venv
if errorlevel 1 goto failed
goto install
:try_python
python -c "import struct,sys; sys.exit(sys.version_info[:2] != (3,12) or struct.calcsize('P') != 8)" >nul 2>nul
if errorlevel 1 goto need_python
python -m venv .venv
if errorlevel 1 goto failed
:install
".venv\Scripts\python.exe" -c "import struct,sys; sys.exit(sys.version_info[:2] != (3,12) or struct.calcsize('P') != 8)"
if errorlevel 1 goto need_python
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
echo.
echo Setup complete. Double-click view.bat to open the field.
popd
pause
exit /b 0
:need_python
echo Python 3.12 64-bit is required. Install it, then run setup.bat again.
echo If .venv was created with another Python version, rename it before retrying.
goto failed
:failed
echo Setup failed. See the error above. Internet access is needed to install packages.
popd
pause
exit /b 1
